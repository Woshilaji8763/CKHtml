import React from 'react';

const Navbar: React.FC = () => {
  return (
    <header>
      <nav className="navbar navbar-default navbar-fixed-top navbar-inverse" role="navigation">
        <div className="container-fluid">
          <div className="navbar-header">
            <button
              type="button"
              className="navbar-toggle collapsed"
              data-toggle="collapse"
              data-target="#top-menu"
              accessKey="m"
            >
              <span className="sr-only">Toggle navigation</span>
              <span className="icon-bar"></span>
            </button>
            <a href="/" className="navbar-brand">
              <img src="https://ext.same-assets.com/2714061179/415771873.png" alt="PHPKOBO" />
            </a>
          </div>
          <div className="collapse navbar-collapse" id="top-menu">
            <ul className="nav navbar-nav navbar-right">
              <li className="dropdown">
                <a href="#" className="dropdown-toggle" data-toggle="dropdown">
                  {' '}
                  Free!
                </a>
                <ul className="dropdown-menu" role="menu">
                  <li>
                    <a href="#">CSS Obfuscator</a>
                  </li>
                  <li>
                    <a href="#">Link Obfuscator</a>
                  </li>
                  <li>
                    <a href="#">HTML Obfuscator</a>
                  </li>
                  <li>
                    <a href="#">AjaxNewsTicker</a>
                  </li>
                  <li>
                    <a href="#">AjaxCountDown</a>
                  </li>
                  <li>
                    <a href="#">Ajax Poll Script</a>
                  </li>
                  <li>
                    <a href="#">php Infinite Scroll</a>
                  </li>
                </ul>
              </li>
              <li className="dropdown">
                <a href="#" className="dropdown-toggle" data-toggle="dropdown">
                  {' '}
                  Scripts
                </a>
                <ul className="dropdown-menu" role="menu">
                  <li>
                    <a href="#">Text Ad Script</a>
                  </li>
                  <li>
                    <a href="#">Ajax Likes Script</a>
                  </li>
                  <li>
                    <a href="#">Fade-In Slideshow</a>
                  </li>
                  <li>
                    <a href="#">Ajax Poll Admin</a>
                  </li>
                  <li>
                    <a href="#">Ajax Poll DBV</a>
                  </li>
                </ul>
              </li>
              <li className="dropdown">
                <a href="#" className="dropdown-toggle" data-toggle="dropdown">
                  {' '}
                  Support
                </a>
                <ul className="dropdown-menu" role="menu">
                  <li>
                    <a href="#">Contact Us</a>
                  </li>
                  <li>
                    <a href="#">Ask a pre-sales question</a>
                  </li>
                  <li>
                    <a href="#">Submit a support ticket</a>
                  </li>
                  <li>
                    <a href="#">Free estimate request form</a>
                  </li>
                </ul>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </header>
  );
};

export default Navbar;
