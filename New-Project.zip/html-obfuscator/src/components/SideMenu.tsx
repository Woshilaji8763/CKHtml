import React from 'react';

const SideMenu: React.FC = () => {
  const menuItems = [
    { id: 1, name: 'Online CSS Obfuscator', href: '#' },
    { id: 2, name: 'Online Link Obfuscator', href: '#' },
    { id: 3, name: 'Online HTML Obfuscator', href: '#', active: true },
    { id: 4, name: 'AjaxNewsTicker', href: '#' },
    { id: 5, name: 'AjaxCountDown', href: '#' },
    { id: 6, name: 'php Infinite Scroll', href: '#' },
    { id: 7, name: 'Fade-In Slideshow', href: '#' },
    { id: 8, name: 'Text Ad Script', href: '#' },
    { id: 9, name: 'Ajax Likes Script', href: '#' },
    { id: 10, name: 'Ajax Poll Admin', href: '#' },
    { id: 11, name: 'Ajax Poll DBV', href: '#' },
    { id: 12, name: 'Ajax Poll Script', href: '#' },
  ];

  return (
    <div className="side-menu">
      {menuItems.map((item) => (
        <a
          key={item.id}
          className={`menu-item ${item.active ? 'active' : ''}`}
          href={item.href}
        >
          <div className="menu-item-tbl">
            <div className="menu-item-row">
              <div className="menu-item-caption">{item.name}</div>
            </div>
          </div>
        </a>
      ))}
    </div>
  );
};

export default SideMenu;
