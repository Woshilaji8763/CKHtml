import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer>
      <img
        className="share-btn share-facebook"
        src="https://ext.same-assets.com/2714061179/33904552.png"
        alt="Facebook"
      />
      <img
        className="share-btn share-twitter"
        src="https://ext.same-assets.com/2714061179/807702483.png"
        alt="Twitter"
      />
      <img
        className="share-btn share-tumblr"
        src="https://ext.same-assets.com/2714061179/3163623463.png"
        alt="Tumblr"
      />
      <img
        className="share-btn share-pinterest"
        src="https://ext.same-assets.com/2714061179/899216919.png"
        alt="Pinterest"
      />
      <img
        className="share-btn share-linkedin"
        src="https://ext.same-assets.com/2714061179/140276124.png"
        alt="LinkedIn"
      />
    </footer>
  );
};

export default Footer;
