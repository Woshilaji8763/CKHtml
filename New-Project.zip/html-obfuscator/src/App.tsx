import React from 'react';
import Navbar from './components/Navbar';
import SideMenu from './components/SideMenu';
import HTMLObfuscator from './components/HTMLObfuscator';
import Footer from './components/Footer';

const App: React.FC = () => {
  return (
    <>
      <Navbar />
      <main>
        <div className="page-body">
          <SideMenu />
          <HTMLObfuscator />
        </div>
      </main>
      <Footer />
    </>
  );
};

export default App;
